package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;

public class Login extends JFrame implements ActionListener {
    JLabel label1, label2, label3;
    JTextField textField2;
    JPasswordField passwordField3;
    JButton button1, button2, button3;

    Login() {
        super("Bank Management System");

        // Get screen dimensions
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int width = screenSize.width;
        int height = screenSize.height;

        setSize(width, height);
        setLocation(0, 0);
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Fullscreen
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setUndecorated(true); // Hide window border

        // Load background image
        ImageIcon bgIcon = new ImageIcon(getClass().getResource("/icon/backbg.png"));
        Image bgImg = bgIcon.getImage().getScaledInstance(width, height, Image.SCALE_DEFAULT);
        JLabel background = new JLabel(new ImageIcon(bgImg));
        background.setBounds(0, 0, width, height);
        background.setLayout(null);
        setContentPane(background);

        // Load bank logo
        ImageIcon bankIcon = new ImageIcon(getClass().getResource("/icon/bank.png"));
        Image bankImg = bankIcon.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT);
        JLabel bankLabel = new JLabel(new ImageIcon(bankImg));
        bankLabel.setBounds(width / 2 - 75, 30, 150, 150);
        background.add(bankLabel);

        // Card icon
        ImageIcon cardIcon = new ImageIcon(getClass().getResource("/icon/card.png"));
        Image cardImg = cardIcon.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        JLabel cardLabel = new JLabel(new ImageIcon(cardImg));
        cardLabel.setBounds(width - 150, height - 150, 100, 100);
        background.add(cardLabel);

        label1 = new JLabel("WELCOME TO ATM");
        label1.setForeground(Color.WHITE);
        label1.setFont(new Font("AvantGarde", Font.BOLD, 48));
        label1.setBounds(width / 2 - 300, 200, 600, 50);
        background.add(label1);

        label2 = new JLabel("Card No:");
        label2.setFont(new Font("Ralway", Font.BOLD, 32));
        label2.setForeground(Color.WHITE);
        label2.setBounds(width / 2 - 300, 300, 200, 40);
        background.add(label2);

        textField2 = new JTextField(15);
        textField2.setBounds(width / 2 - 50, 300, 300, 40);
        textField2.setFont(new Font("Arial", Font.BOLD, 18));
        background.add(textField2);

        label3 = new JLabel("PIN:");
        label3.setFont(new Font("Ralway", Font.BOLD, 32));
        label3.setForeground(Color.WHITE);
        label3.setBounds(width / 2 - 300, 370, 200, 40);
        background.add(label3);

        passwordField3 = new JPasswordField(15);
        passwordField3.setBounds(width / 2 - 50, 370, 300, 40);
        passwordField3.setFont(new Font("Arial", Font.BOLD, 18));
        background.add(passwordField3);

        button1 = new JButton("SIGN IN");
        button1.setFont(new Font("Arial", Font.BOLD, 18));
        button1.setForeground(Color.WHITE);
        button1.setBackground(Color.BLACK);
        button1.setBounds(width / 2 - 160, 450, 130, 40);
        button1.addActionListener(this);
        background.add(button1);

        button2 = new JButton("CLEAR");
        button2.setFont(new Font("Arial", Font.BOLD, 18));
        button2.setForeground(Color.WHITE);
        button2.setBackground(Color.BLACK);
        button2.setBounds(width / 2 + 40, 450, 130, 40);
        button2.addActionListener(this);
        background.add(button2);

        button3 = new JButton("SIGN UP");
        button3.setFont(new Font("Arial", Font.BOLD, 18));
        button3.setForeground(Color.WHITE);
        button3.setBackground(Color.BLACK);
        button3.setBounds(width / 2 - 160, 510, 330, 40);
        button3.addActionListener(this);
        background.add(button3);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            if (e.getSource() == button1) {
                Connn c = new Connn();
                String cardno = textField2.getText();
                String pin = passwordField3.getText();
                String q = "select * from login where card_number = '" + cardno + "' and pin = '" + pin + "'";
                ResultSet resultSet = c.statement.executeQuery(q);
                if (resultSet.next()) {
                    setVisible(false);
                    new main_Class(pin);
                } else {
                    JOptionPane.showMessageDialog(null, "Incorrect Card Number or PIN");
                }
            } else if (e.getSource() == button2) {
                textField2.setText("");
                passwordField3.setText("");
            } else if (e.getSource() == button3) {
                new Signup();
                setVisible(false);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Login();
    }
}
