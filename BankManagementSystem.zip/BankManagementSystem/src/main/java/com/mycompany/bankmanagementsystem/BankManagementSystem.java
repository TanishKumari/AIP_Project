/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bankmanagementsystem;

/**
 *
 * @author suren
 */
public class BankManagementSystem {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
